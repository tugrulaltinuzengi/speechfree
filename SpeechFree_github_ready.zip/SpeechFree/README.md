# SpeechFree — Wearable Silent Speech Interface

> A multimodal wearable system that decodes silent articulation from neck-surface biosignals into synthesized Turkish speech, designed for post-laryngectomy voice restoration.

**Status:** Active research prototype (FENS 402 — Engineering Design Project, Kadir Has University, May 2026)

---

## Overview

Total laryngectomy permanently removes the larynx and eliminates biological phonation. Existing voice-restoration options (electrolarynx, esophageal speech, tracheoesophageal puncture) each carry significant clinical, functional, or acoustic limitations.

SpeechFree is a non-invasive wearable that captures **mechanomyographic (MMG)** vibrations and **submental sEMG** from anatomical sites unaffected by the surgery, decodes them locally on an Android device using a 1D-CNN, and re-vocalizes the recognized word through a personalized voice clone of the patient's pre-operative voice.

The full pipeline — sensor acquisition, causal DSP, voice activity detection, neural inference, TTS synthesis — runs **on-device, offline**, satisfying KVKK/GDPR biometric data protection requirements.

---

## Key features

- **5-channel biosignal acquisition** (1 sEMG + 4 PZT) at 500 Hz on a custom 3D-printed PLA cervical band (12 g).
- **Bit-exact Python ↔ Kotlin signal-processing parity** via JSON-serialized filter coefficients and VAD constants — eliminates training-vs-deployment drift.
- **Causal IIR DSP**: 4th-order Butterworth bandpass (EMG 20–200 Hz, PZT 5–200 Hz) + 50 Hz high-Q notch filter (Q=30).
- **Voice Activity Detection** state machine (SILENCE → SPEAKING → TAILING_OFF) with EMA envelope (fc=5 Hz), dynamic μ+3σ thresholding, and 100 ms pre-roll ring buffer.
- **1D-CNN classifier** (~250 k params, <5 MB ONNX, <100 ms inference) over 10-class Turkish vocabulary: `EVET, HAYIR, MERHABA, TESEKKURLER, SU, YARDIM, TAMAM, DUR, GEL, GUNAYDIN`.
- **Personalized voice cloning** via ElevenLabs API from 2 minutes of pre-operative reference audio.
- **Android edge deployment** with ONNX Runtime, Jetpack Compose, MVVM + Hilt + Room DB, Foreground Service.

---

## Results (pilot session, single subject)

| Metric | Value |
|---|---|
| Random Forest baseline — within-session top-1 | **67%** |
| Random Forest baseline — within-session top-3 | **87%** |
| 1D-CNN cross-session top-1 (kayit1 → kayit3) | **52%** |
| 1D-CNN cross-session top-3 | **75%** |
| Random-chance baseline (10 classes) | 10% |
| VAD word-level match rate (k=1.5 threshold) | 66% |
| VAD onset MAE | 710 ms |
| Mean IoU (detected vs. ground-truth windows) | 0.556 |

Words with distinct stop-onset articulation (`DUR`, `TAMAM`, `GEL`) generalize best across sessions. Fricative-initial words (`HAYIR`, `MERHABA`) remain the principal classification challenge — motivating multi-modal VAD that incorporates the PZT channels.

Full methodology, ablation studies, and analysis in [`docs/FENS402_Final_Report.pdf`](docs/FENS402_Final_Report.pdf).

---

## System architecture

The software is decomposed into 5 logical layers, physically split across an embedded edge node and an Android host:

1. **Acquisition firmware** (C/C++ on Arduino Uno PoC, scaling to ESP32-S3) — deterministic 500 Hz sampling, ADC prescaler optimization (1 MHz), double-read for inter-channel crosstalk mitigation, UART command/response protocol at 250 kbaud.
2. **Data collection & QC toolchain** (MATLAB) — automated clinical protocol orchestration, signal quality verification (saturation / mains / baseline / A/B ratio), marker-based event tagging, session metadata schema.
3. **Offline ML pipeline** (Python: PyTorch, scikit-learn, SciPy) — causal preprocessing, VAD, Random Forest baseline, 1D-CNN training with channel dropout and temporal-shift augmentation, ROC-based confidence threshold calibration via Youden's J, ONNX export, regression fixtures.
4. **Mobile inference pipeline** (Kotlin, ONNX Runtime) — pluggable transport (BLE / USB / UDP / Mock) via Strategy Pattern, bit-exact causal filtering, Kotlin VAD state machine port, softmax confidence gating, Foreground Service.
5. **Mobile UX & persistence** (Jetpack Compose, Hilt, Room, DataStore) — calibration onboarding, real-time signal visualizer, history log, settings.

Cross-layer data contracts (`preprocessing_params.json`, `vad_constants.json`, `confidence_threshold.json`, `labels.json`, `electrolarynx_classifier.onnx`, regression fixtures) form the "single source of truth" between Python and Kotlin.

---

## Repository structure

```
SpeechFree/
├── Final/                          Hardware + acquisition layer
│   ├── ESP32_Electrolarynx_Recorder/
│   │   └── ESP32_Electrolarynx_Recorder.ino    ESP32-S3 firmware
│   ├── DEMO_VAD_6ch.m                          MATLAB clinical protocol
│   ├── README_KAYIT.md                         Hardware setup guide (TR)
│   └── recordings/                             Sample sessions (markers only)
├── TextRecon/                      Offline ML pipeline (Python)
│   ├── signal_processing.py                    Causal IIR filters
│   ├── vad.py                                  VAD state machine
│   ├── models.py                               1D-CNN architecture
│   ├── train.py                                Training loop
│   ├── rf_baseline.py                          Random Forest baseline
│   ├── confidence_analysis.py                  ROC + Youden's J calibration
│   ├── export_onnx.py                          ONNX serialization
│   ├── generate_fixtures.py                    Python↔Kotlin parity fixtures
│   └── dataset.npz                             Compiled dataset
├── TTS/                            Voice cloning pipeline
│   ├── 01_data_prep/                           Audio preprocessing
│   ├── 02_finetune/                            VITS Turkish fine-tuning
│   ├── 03_onnx_export/                         ONNX export + verification
│   ├── 04_evaluation/                          MCD + perceptual eval
│   ├── 05_prerendered/                         ElevenLabs prerendering
│   ├── 06_deliverable/                         Mobile-ready assets + Kotlin player
│   └── tester/                                 Unit tests
├── tugrul_paket/                   VAD evaluation + retraining sub-task
│   ├── DIRECTION_TUGRUL.md                     Task description (TR)
│   ├── model_and_shi/                          3-channel adapted code + base model
│   └── recordings/                             4 multi-modal sessions (markers + sensors)
└── pipeline_health_check.html      Diagnostic report
```

---

## Tech stack

**Hardware** — ESP32-S3 / Arduino Uno · 4× PZT lead zirconate titanate discs (25 mm) · 1× sEMG bipolar pair + REF · 3D-printed PLA cervical band · 9V isolated battery supply · TL072 op-amp piezo buffers

**Embedded** — C/C++ (Arduino), Timer1 CTC mode, direct ADCSRA register manipulation, UART @ 250 kbaud

**Data collection** — MATLAB R202x · custom UART parser · session metadata JSON schema

**ML / DSP** — Python 3.11 · PyTorch · scikit-learn · SciPy (`signal.lfilter`, `signal.butter`, `signal.iirnotch`) · NumPy · Welch PSD · ONNX Opset 14

**Mobile** — Kotlin · Jetpack Compose · Dagger-Hilt · Room · DataStore · Kotlin Coroutines/Flow · ONNX Runtime for Android · ai.onnxruntime

**Voice cloning** — VITS (fine-tuned) · ElevenLabs API · Turkish phoneme cleaners

---

## Compliance & standards

The system is designed against:

- **IEC 60601-1** — Medical electrical equipment, basic safety and essential performance
- **IEC 60601-1-2** — Electromagnetic compatibility
- **IEC 60601-1-11** — Home healthcare environment requirements
- **IEC 62304** — Medical device software life cycle
- **ISO 10993-5 / -10 / -23** — Biological evaluation (cytotoxicity, sensitization, irritation)
- **TİTCK / EU MDR 2017/745** — Turkish and EU medical device regulations
- **KVKK / GDPR** — Biometric data protection (Privacy-by-Design, on-device inference)
- **EU RoHS** — Hazardous substances (PZT exemption 7(c)-I)

---

## Team

Group 10 — Kadir Has University, Electrical & Electronics Engineering, FENS 402:

- Tuğrul Altınüzengi — Signal processing, ML pipeline, Android inference layer
- Serhat Yalçın
- Mert Kaçmaz
- Yiğit Efe Ayhan

**Supervisor:** Yalçın Şadi

---

## Data availability

Sample recordings (markers, session metadata, sensor data from `tugrul_paket/`) are included in the repository. Large raw recordings (`raw_6ch.csv`, `*_SES.wav`) are excluded from version control for size reasons — available on request.

---

## License

MIT License — see [`LICENSE`](LICENSE).

This is an academic research prototype. It is **not** a certified medical device and must not be used for clinical purposes without full regulatory validation.
